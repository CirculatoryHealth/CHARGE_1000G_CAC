#!/bin/bash
#
/hpc/local/CentOS7/dhl_ec/software/GWASToolKit/gwastoolkit.wrapper.sh /hpc/dhl_ec/svanderlaan/projects/lookups/AE_20200512_COL_MKAVOUSI_MBOS_CHARGE_1000G_CAC/SNP/gwastoolkit.credset.conf Fat10 
